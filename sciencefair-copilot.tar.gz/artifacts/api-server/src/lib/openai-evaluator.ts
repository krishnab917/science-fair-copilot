import { openai } from "@workspace/integrations-openai-ai-server";
import { logger } from "./logger";

export interface EvaluationCategory {
  score: number;
  reasoning: string;
  suggestion: string;
}

export interface EvaluationResult {
  scientific_validity: EvaluationCategory;
  feasibility: EvaluationCategory;
  originality: EvaluationCategory;
  engineering_complexity: EvaluationCategory;
  judge_appeal: EvaluationCategory;
  scalability: EvaluationCategory;
  data_quality: EvaluationCategory;
  failure_risk: EvaluationCategory;
  overall_score: number;
  strongest_aspect: string;
  weakest_aspect: string;
  judge_summary: string;
}

const SYSTEM_PROMPT = `You are an elite science fair judge and STEM research mentor with 20+ years of experience judging regional, state, and national competitions including ISEF.

Evaluate the student project using rigorous scientific reasoning. Be critical but constructive. Avoid generic praise.

Return ONLY valid JSON with exactly this structure:
{
  "scientific_validity": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "feasibility": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "originality": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "engineering_complexity": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "judge_appeal": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "scalability": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "data_quality": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "failure_risk": { "score": 0-10, "reasoning": "string", "suggestion": "string" },
  "overall_score": 0-10,
  "strongest_aspect": "category name",
  "weakest_aspect": "category name",
  "judge_summary": "2-3 sentences summarizing the project's merit and key recommendation"
}

For each category provide:
- score: integer from 0-10 (10 = exceptional, 5 = average, 0 = fundamentally flawed)
- reasoning: 1-2 sentences explaining the score with specifics
- suggestion: 1 actionable improvement the student can implement

failure_risk score interpretation: 10 means very low risk (good), 0 means very high risk (bad).`;

export async function evaluateProject(project: {
  title: string;
  description: string;
  gradeLevel: string;
  budget: string;
  timeline: string;
}): Promise<EvaluationResult> {
  const userPrompt = `Evaluate this science fair project:

Title: ${project.title}
Description: ${project.description}
Grade Level: ${project.gradeLevel}
Budget: ${project.budget}
Timeline: ${project.timeline}

Return ONLY the JSON evaluation.`;

  const response = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 8192,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userPrompt },
    ],
    response_format: { type: "json_object" },
  });

  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("No content returned from OpenAI");
  }

  let parsed: EvaluationResult;
  try {
    parsed = JSON.parse(content) as EvaluationResult;
  } catch (err) {
    logger.error({ err, content }, "Failed to parse OpenAI response as JSON");
    throw new Error("AI returned invalid JSON");
  }

  return parsed;
}
