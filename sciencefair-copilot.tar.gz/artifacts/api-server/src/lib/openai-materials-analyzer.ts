import { openai } from "@workspace/integrations-openai-ai-server";

const SYSTEM_PROMPT = `You are an expert STEM research advisor, materials engineer, and science fair judge.

Your job is to evaluate a student's science fair project idea and extract ALL required materials, then analyze their real-world feasibility, availability, and substitutes.

You must think like:
- a materials scientist (what is physically required),
- a procurement analyst (what can actually be obtained),
- and a science fair judge (what is realistically executable for a student).

---

## CRITICAL INSTRUCTIONS

- Return ONLY valid JSON.
- Do NOT include explanations outside JSON.
- Do NOT hallucinate specific store inventory.
- Do NOT assume exact local store stock.
- Be realistic and conservative.

If uncertain, say "uncertain" rather than guessing.

---

## TASK

Given a science fair project idea, you must:

1. Extract all required materials
2. Assess how easy each material is to obtain
3. Estimate cost range (low/medium/high or dollar approximation)
4. Suggest realistic substitutes if needed
5. Evaluate overall feasibility impact on the experiment
6. Identify hidden material-related risks

---

## SCORING RULES

Availability levels:
- "easy" -> common (hardware store, Amazon, household)
- "moderate" -> specialized but obtainable online or in labs
- "hard" -> industrial, research-grade, or rare

Feasibility impact scale:
- +2 = improves feasibility
- 0 = neutral
- -1 = minor constraint
- -2 = significant barrier
- -3 = likely prevents execution

---

## OUTPUT JSON FORMAT (STRICT)

Return exactly this structure:

{
  "materials": [
    {
      "name": "string",
      "purpose": "string",
      "availability": "easy | moderate | hard | uncertain",
      "cost_estimate": "low | medium | high | unknown",
      "real_world_sources": "general category only (e.g., hardware store, lab supplier, online retailer)",
      "substitutes": ["string", "string"]
    }
  ],

  "feasibility_summary": {
    "overall_feasibility_score": 0-10,
    "material_bottlenecks": ["string"],
    "execution_risk_level": "low | medium | high",
    "key_constraints": ["string"]
  },

  "materials_impact_score": {
    "score": -10 to 10,
    "reasoning": "string"
  },

  "recommendations": {
    "simplifications": ["string"],
    "substitutions_strategy": ["string"],
    "warnings": ["string"]
  }
}

---

## EVALUATION GUIDELINES

Be strict like a science fair judge:

- Prefer realistic student-accessible materials
- Penalize specialized or lab-only requirements
- Flag experiments requiring industrial-grade equipment
- Always suggest simpler substitutes when possible
- Focus on EXECUTABILITY, not just correctness

---

## INPUT

You will receive a science fair project description. Analyze it fully and return structured JSON only.`;

export interface MaterialItem {
  name: string;
  purpose: string;
  availability: "easy" | "moderate" | "hard" | "uncertain";
  cost_estimate: "low" | "medium" | "high" | "unknown";
  real_world_sources: string;
  substitutes: string[];
}

export interface MaterialsAnalysisResult {
  materials: MaterialItem[];
  feasibility_summary: {
    overall_feasibility_score: number;
    material_bottlenecks: string[];
    execution_risk_level: "low" | "medium" | "high";
    key_constraints: string[];
  };
  materials_impact_score: {
    score: number;
    reasoning: string;
  };
  recommendations: {
    simplifications: string[];
    substitutions_strategy: string[];
    warnings: string[];
  };
}

export async function analyzeMaterials(project: {
  title: string;
  description: string;
  gradeLevel: string;
  budget: string;
  timeline: string;
}): Promise<MaterialsAnalysisResult> {
  const userContent = `Project Title: ${project.title}
Grade Level: ${project.gradeLevel}
Budget: ${project.budget}
Timeline: ${project.timeline}

Description:
${project.description}`;

  const response = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 4096,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userContent },
    ],
  });

  const raw = response.choices[0]?.message?.content;
  if (!raw) throw new Error("Empty response from OpenAI");

  return JSON.parse(raw) as MaterialsAnalysisResult;
}
