import { Router, type IRouter } from "express";
import { eq, avg, desc } from "drizzle-orm";
import { db, projectsTable, evaluationsTable } from "@workspace/db";
import {
  CreateProjectBody,
  GetProjectParams,
  EvaluateProjectParams,
} from "@workspace/api-zod";
import { evaluateProject } from "../lib/openai-evaluator";

const router: IRouter = Router();

router.get("/projects", async (req, res): Promise<void> => {
  const projects = await db
    .select()
    .from(projectsTable)
    .orderBy(desc(projectsTable.createdAt));
  res.json(projects.map((p) => ({
    ...p,
    createdAt: p.createdAt.toISOString(),
  })));
});

router.post("/projects", async (req, res): Promise<void> => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [project] = await db
    .insert(projectsTable)
    .values({
      title: parsed.data.title,
      description: parsed.data.description,
      gradeLevel: parsed.data.gradeLevel,
      budget: parsed.data.budget,
      timeline: parsed.data.timeline,
    })
    .returning();

  res.status(201).json({ ...project, createdAt: project.createdAt.toISOString() });
});

router.get("/projects/stats/summary", async (req, res): Promise<void> => {
  const projects = await db.select().from(projectsTable);
  const evaluations = await db.select().from(evaluationsTable);

  const totalProjects = projects.length;

  const scored = evaluations.filter((e) => e.overallScore != null);
  const averageScore = scored.length > 0
    ? scored.reduce((sum, e) => sum + e.overallScore, 0) / scored.length
    : 0;

  const topEval = evaluations.sort((a, b) => b.overallScore - a.overallScore)[0];
  const topProject = topEval
    ? projects.find((p) => p.id === topEval.projectId) ?? null
    : null;

  const gradeLevelMap: Record<string, number> = {};
  for (const p of projects) {
    gradeLevelMap[p.gradeLevel] = (gradeLevelMap[p.gradeLevel] ?? 0) + 1;
  }
  const gradeLevelBreakdown = Object.entries(gradeLevelMap).map(([gradeLevel, count]) => ({
    gradeLevel,
    count,
  }));

  res.json({
    totalProjects,
    averageScore: Math.round(averageScore * 10) / 10,
    topProject: topProject ? { ...topProject, createdAt: topProject.createdAt.toISOString() } : null,
    gradeLevelBreakdown,
  });
});

router.get("/projects/:id", async (req, res): Promise<void> => {
  const params = GetProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.id));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const [evaluation] = await db
    .select()
    .from(evaluationsTable)
    .where(eq(evaluationsTable.projectId, params.data.id))
    .orderBy(desc(evaluationsTable.createdAt));

  res.json({
    project: { ...project, createdAt: project.createdAt.toISOString() },
    evaluation: evaluation
      ? {
          ...evaluation,
          createdAt: evaluation.createdAt.toISOString(),
        }
      : undefined,
  });
});

router.post("/projects/:id/evaluate", async (req, res): Promise<void> => {
  const params = EvaluateProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.id));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  req.log.info({ projectId: project.id }, "Starting AI evaluation");

  let result;
  try {
    result = await evaluateProject({
      title: project.title,
      description: project.description,
      gradeLevel: project.gradeLevel,
      budget: project.budget,
      timeline: project.timeline,
    });
  } catch (err) {
    req.log.error({ err }, "AI evaluation failed");
    res.status(500).json({ error: "AI evaluation failed. Please try again." });
    return;
  }

  const [evaluation] = await db
    .insert(evaluationsTable)
    .values({
      projectId: project.id,
      overallScore: result.overall_score,
      strongestAspect: result.strongest_aspect,
      weakestAspect: result.weakest_aspect,
      judgeSummary: result.judge_summary,
      scientificValidity: result.scientific_validity,
      feasibility: result.feasibility,
      originality: result.originality,
      engineeringComplexity: result.engineering_complexity,
      judgeAppeal: result.judge_appeal,
      scalability: result.scalability,
      dataQuality: result.data_quality,
      failureRisk: result.failure_risk,
    })
    .returning();

  res.json({ ...evaluation, createdAt: evaluation.createdAt.toISOString() });
});

export default router;
