import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, projectsTable, evaluationsTable } from "@workspace/db";
import { RetryEvaluationParams } from "@workspace/api-zod";
import { evaluateProject } from "../lib/openai-evaluator";

const router: IRouter = Router();

router.post("/evaluations/:id/retry", async (req, res): Promise<void> => {
  const params = RetryEvaluationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existingEval] = await db
    .select()
    .from(evaluationsTable)
    .where(eq(evaluationsTable.id, params.data.id));

  if (!existingEval) {
    res.status(404).json({ error: "Evaluation not found" });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, existingEval.projectId));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  req.log.info({ projectId: project.id, prevEvalId: existingEval.id }, "Retrying AI evaluation");

  let result;
  try {
    result = await evaluateProject({
      title: project.title,
      description: project.description,
      gradeLevel: project.gradeLevel,
      budget: project.budget,
      timeline: project.timeline,
    });
  } catch (err) {
    req.log.error({ err }, "AI evaluation retry failed");
    res.status(500).json({ error: "AI evaluation failed. Please try again." });
    return;
  }

  const [evaluation] = await db
    .insert(evaluationsTable)
    .values({
      projectId: project.id,
      overallScore: result.overall_score,
      strongestAspect: result.strongest_aspect,
      weakestAspect: result.weakest_aspect,
      judgeSummary: result.judge_summary,
      scientificValidity: result.scientific_validity,
      feasibility: result.feasibility,
      originality: result.originality,
      engineeringComplexity: result.engineering_complexity,
      judgeAppeal: result.judge_appeal,
      scalability: result.scalability,
      dataQuality: result.data_quality,
      failureRisk: result.failure_risk,
    })
    .returning();

  res.json({ ...evaluation, createdAt: evaluation.createdAt.toISOString() });
});

export default router;
