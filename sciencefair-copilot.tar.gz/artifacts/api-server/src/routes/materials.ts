import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, projectsTable, materialsAnalysisTable } from "@workspace/db";
import { GetProjectParams } from "@workspace/api-zod";
import { analyzeMaterials } from "../lib/openai-materials-analyzer";

const router: IRouter = Router();

router.get("/projects/:id/materials", async (req, res): Promise<void> => {
  const params = GetProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.id));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const [analysis] = await db
    .select()
    .from(materialsAnalysisTable)
    .where(eq(materialsAnalysisTable.projectId, params.data.id))
    .orderBy(desc(materialsAnalysisTable.createdAt));

  if (!analysis) {
    res.status(404).json({ error: "No materials analysis found for this project" });
    return;
  }

  res.json({ ...analysis, createdAt: analysis.createdAt.toISOString() });
});

router.post("/projects/:id/materials", async (req, res): Promise<void> => {
  const params = GetProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.id));

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  req.log.info({ projectId: project.id }, "Starting AI materials analysis");

  let result;
  try {
    result = await analyzeMaterials({
      title: project.title,
      description: project.description,
      gradeLevel: project.gradeLevel,
      budget: project.budget,
      timeline: project.timeline,
    });
  } catch (err) {
    req.log.error({ err }, "AI materials analysis failed");
    res.status(500).json({ error: "AI materials analysis failed. Please try again." });
    return;
  }

  const [analysis] = await db
    .insert(materialsAnalysisTable)
    .values({
      projectId: project.id,
      materials: result.materials,
      feasibilitySummary: result.feasibility_summary,
      materialsImpactScore: result.materials_impact_score,
      recommendations: result.recommendations,
    })
    .returning();

  res.json({ ...analysis, createdAt: analysis.createdAt.toISOString() });
});

export default router;
