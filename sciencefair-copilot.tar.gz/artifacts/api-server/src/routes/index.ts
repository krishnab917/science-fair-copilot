import { Router, type IRouter } from "express";
import healthRouter from "./health";
import projectsRouter from "./projects";
import evaluationsRouter from "./evaluations";
import materialsRouter from "./materials";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectsRouter);
router.use(evaluationsRouter);
router.use(materialsRouter);

export default router;
