import { Link } from "wouter";
import { useGetProjectStats } from "@workspace/api-client-react";
import { FlaskConical, Trophy, ArrowRight, Zap } from "lucide-react";

const RUBRIC_CATS = [
  { name: "Scientific Validity", desc: "Experimental rigor and methodology" },
  { name: "Feasibility", desc: "Practicality within constraints" },
  { name: "Originality", desc: "Novelty and creative contribution" },
  { name: "Engineering Complexity", desc: "Technical depth and sophistication" },
  { name: "Judge Appeal", desc: "Presentation and communication potential" },
  { name: "Scalability", desc: "Growth and expansion potential" },
  { name: "Data Quality", desc: "Measurement precision and reliability" },
  { name: "Failure Risk", desc: "Project resilience and contingency" },
];

export default function Home() {
  const { data: stats } = useGetProjectStats();

  return (
    <div className="min-h-screen bg-[hsl(222,47%,7%)] text-white">

      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b border-white/[0.06] bg-[hsl(222,47%,7%)]/80 backdrop-blur-md px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[hsl(210,100%,60%)]/15 flex items-center justify-center ring-1 ring-[hsl(210,100%,60%)]/30">
              <FlaskConical className="w-4 h-4 text-[hsl(210,100%,60%)]" />
            </div>
            <span className="font-semibold text-[15px] tracking-tight">ScienceFair Copilot</span>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/projects" className="text-sm text-white/50 hover:text-white/90 transition-colors px-3 py-1.5 rounded-md hover:bg-white/[0.06]">
              My Projects
            </Link>
            <Link
              href="/submit"
              className="text-sm bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-semibold px-4 py-1.5 rounded-lg hover:bg-[hsl(210,100%,68%)] transition-colors shadow-lg shadow-[hsl(210,100%,60%)]/20"
              data-testid="link-get-started"
            >
              Evaluate Idea
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative max-w-6xl mx-auto px-6 pt-28 pb-24 overflow-hidden">
        {/* Glow */}
        <div className="pointer-events-none absolute -top-20 -left-20 w-[600px] h-[500px] rounded-full bg-[hsl(210,100%,55%)]/[0.07] blur-[120px]" />
        <div className="pointer-events-none absolute top-10 right-0 w-[400px] h-[400px] rounded-full bg-[hsl(180,100%,50%)]/[0.05] blur-[100px]" />

        <div className="relative max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-[hsl(210,100%,60%)]/[0.08] border border-[hsl(210,100%,60%)]/20 rounded-full px-3.5 py-1.5 mb-8">
            <Zap className="w-3 h-3 text-[hsl(210,100%,65%)]" />
            <span className="text-[11px] text-[hsl(210,100%,70%)] font-semibold tracking-[0.08em] uppercase">AI-Powered Rubric Engine</span>
          </div>

          <h1 className="text-5xl sm:text-[64px] font-extrabold leading-[1.05] tracking-tighter mb-6">
            Turn science fair ideas into{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[hsl(210,100%,65%)] via-[hsl(200,100%,60%)] to-[hsl(175,100%,55%)]">
              judge-proof experiments.
            </span>
          </h1>

          <p className="text-lg text-white/50 leading-relaxed mb-10 max-w-xl font-light">
            Expert-level feedback across 8 critical dimensions — like standing in front of a real panel of STEM judges.
          </p>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link
              href="/submit"
              className="inline-flex items-center justify-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold px-7 py-3.5 rounded-xl text-[15px] hover:bg-[hsl(210,100%,68%)] transition-colors shadow-xl shadow-[hsl(210,100%,60%)]/25"
              data-testid="link-cta-evaluate"
            >
              Evaluate My Idea
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/projects"
              className="inline-flex items-center justify-center gap-2 border border-white/12 text-white/70 font-medium px-7 py-3.5 rounded-xl text-[15px] hover:bg-white/[0.05] hover:text-white hover:border-white/20 transition-all"
              data-testid="link-view-projects"
            >
              My Projects
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      {stats && (
        <section className="border-y border-white/[0.06]">
          <div className="max-w-6xl mx-auto px-6 py-10 grid grid-cols-2 sm:grid-cols-4 gap-8">
            {[
              { value: stats.totalProjects.toString(), label: "Projects Evaluated" },
              { value: stats.averageScore > 0 ? stats.averageScore.toFixed(1) : "—", label: "Average Score", accent: true },
              { value: stats.gradeLevelBreakdown.length.toString(), label: "Grade Levels" },
              { value: "8", label: "Rubric Dimensions" },
            ].map(({ value, label, accent }) => (
              <div key={label} className="text-center">
                <div className={`text-4xl font-black tracking-tight tabular-nums ${accent ? "text-[hsl(210,100%,65%)]" : "text-white"}`} data-testid={`stat-${label.toLowerCase().replace(/ /g, "-")}`}>
                  {value}
                </div>
                <div className="text-xs text-white/40 mt-1.5 font-medium tracking-wide uppercase">{label}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Rubric grid */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="mb-10">
          <h2 className="text-2xl font-bold tracking-tight mb-2">What gets evaluated</h2>
          <p className="text-white/40 text-sm">Every project scored across 8 dimensions, each with detailed reasoning and improvement suggestions.</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {RUBRIC_CATS.map((cat, i) => (
            <div
              key={cat.name}
              className="group bg-white/[0.03] border border-white/[0.07] rounded-xl p-5 hover:bg-white/[0.06] hover:border-white/[0.12] transition-all"
            >
              <div className="text-[10px] font-bold text-white/20 tabular-nums mb-3">0{i + 1}</div>
              <div className="font-semibold text-[13px] mb-1 text-white/90">{cat.name}</div>
              <div className="text-[11px] text-white/35 leading-relaxed">{cat.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Top project */}
      {stats?.topProject && (
        <section className="max-w-6xl mx-auto px-6 pb-20">
          <div className="relative overflow-hidden bg-gradient-to-br from-[hsl(210,100%,60%)]/[0.08] to-[hsl(180,100%,50%)]/[0.05] border border-[hsl(210,100%,60%)]/15 rounded-2xl p-8">
            <div className="absolute inset-0 bg-gradient-to-r from-[hsl(210,100%,60%)]/[0.03] to-transparent pointer-events-none" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-3">
                <Trophy className="w-3.5 h-3.5 text-[hsl(45,100%,65%)]" />
                <span className="text-[10px] text-[hsl(45,100%,65%)] font-bold uppercase tracking-[0.1em]">Top Rated Project</span>
              </div>
              <h3 className="text-xl font-bold tracking-tight mb-1" data-testid="top-project-title">{stats.topProject.title}</h3>
              <p className="text-white/40 text-sm mb-5">Grade {stats.topProject.gradeLevel}</p>
              <Link
                href={`/results/${stats.topProject.id}`}
                className="inline-flex items-center gap-1.5 text-sm text-[hsl(210,100%,65%)] hover:text-[hsl(210,100%,75%)] transition-colors font-semibold"
              >
                View Evaluation <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-white/[0.06] py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-3.5 h-3.5 text-[hsl(210,100%,60%)]/60" />
            <span className="text-xs text-white/25 font-medium">ScienceFair Copilot</span>
          </div>
          <p className="text-xs text-white/20">AI-powered science fair evaluation</p>
        </div>
      </footer>
    </div>
  );
}
