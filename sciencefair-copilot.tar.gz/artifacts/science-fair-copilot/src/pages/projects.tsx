import { Link } from "wouter";
import { useListProjects } from "@workspace/api-client-react";
import { FlaskConical, Plus, ArrowRight, Calendar, GraduationCap } from "lucide-react";
import { getMyProjectIds } from "@/hooks/use-my-projects";

export default function Projects() {
  const { data: allProjects, isLoading } = useListProjects();
  const myIds = getMyProjectIds();
  const projects = allProjects?.filter((p) => myIds.includes(p.id));

  return (
    <div className="min-h-screen bg-[hsl(222,47%,8%)] text-white">
      {/* Nav */}
      <nav className="border-b border-white/10 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
            <FlaskConical className="w-5 h-5 text-[hsl(210,100%,60%)]" />
            <span className="font-bold">ScienceFair Copilot</span>
          </Link>
          <Link
            href="/submit"
            className="flex items-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold text-sm px-4 py-2 rounded-lg hover:bg-[hsl(210,100%,70%)] transition-colors"
            data-testid="link-new-project"
          >
            <Plus className="w-4 h-4" />
            New Project
          </Link>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My Projects</h1>
          <p className="text-white/50">Your submitted science fair projects and their AI evaluation scores.</p>
        </div>

        {isLoading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white/[0.04] border border-white/10 rounded-xl p-5 animate-pulse">
                <div className="h-4 bg-white/10 rounded mb-3 w-3/4" />
                <div className="h-3 bg-white/10 rounded w-1/2" />
              </div>
            ))}
          </div>
        )}

        {!isLoading && (!projects || projects.length === 0) && (
          <div className="flex flex-col items-center justify-center py-32 gap-4 border border-white/10 rounded-2xl">
            <FlaskConical className="w-12 h-12 text-white/20" />
            <div className="text-center">
              <div className="font-semibold text-white/60 mb-1">No projects yet</div>
              <div className="text-sm text-white/30">Projects you submit will appear here</div>
            </div>
            <Link
              href="/submit"
              className="mt-2 flex items-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold px-5 py-2.5 rounded-lg hover:bg-[hsl(210,100%,70%)] transition-colors text-sm"
            >
              Submit First Project
            </Link>
          </div>
        )}

        {!isLoading && projects && projects.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map((project) => (
              <Link
                key={project.id}
                href={`/results/${project.id}`}
                className="group bg-white/[0.04] border border-white/10 rounded-xl p-5 hover:bg-white/[0.07] hover:border-white/20 transition-all flex flex-col gap-3"
                data-testid={`card-project-${project.id}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-semibold text-sm leading-snug line-clamp-2 flex-1" data-testid={`text-project-title-${project.id}`}>
                    {project.title}
                  </h3>
                  <ArrowRight className="w-4 h-4 text-white/30 group-hover:text-white/60 flex-shrink-0 mt-0.5 transition-colors" />
                </div>

                <div className="flex items-center gap-3 text-xs text-white/40">
                  <span className="flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5" />
                    {project.gradeLevel}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(project.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <p className="text-xs text-white/30 line-clamp-2 leading-relaxed">{project.description}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
