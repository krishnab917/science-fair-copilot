import { useParams, Link } from "wouter";
import {
  useGetProject,
  useRetryEvaluation,
  useGetMaterialsAnalysis,
  useAnalyzeMaterials,
  getGetProjectQueryKey,
  getGetMaterialsAnalysisQueryKey,
} from "@workspace/api-client-react";
import type { MaterialItem, MaterialsAnalysis } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import {
  FlaskConical, ArrowLeft, RotateCcw, Loader2,
  CheckCircle2, AlertTriangle, ChevronRight,
  Package, Zap, ShieldAlert, Lightbulb, ChevronDown, ChevronUp,
} from "lucide-react";

const CATEGORY_LABELS: Record<string, string> = {
  scientificValidity: "Scientific Validity",
  feasibility: "Feasibility",
  originality: "Originality",
  engineeringComplexity: "Engineering Complexity",
  judgeAppeal: "Judge Appeal",
  scalability: "Scalability",
  dataQuality: "Data Quality",
  failureRisk: "Failure Risk",
};

function formatAspectName(raw: string): string {
  // Convert snake_case or camelCase keys to display names
  const key = raw
    .replace(/_([a-z])/g, (_, c: string) => c.toUpperCase())
    .replace(/^[a-z]/, (c) => c.toUpperCase());
  return CATEGORY_LABELS[raw] ?? CATEGORY_LABELS[key] ?? raw
    .replace(/_/g, " ")
    .replace(/([A-Z])/g, " $1")
    .replace(/^\s/, "")
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

interface EvalCategory {
  score: number;
  reasoning: string;
  suggestion: string;
}

function ScoreRing({ score, size = 120 }: { score: number; size?: number }) {
  const radius = size / 2 - 14;
  const circumference = 2 * Math.PI * radius;
  const filled = (score / 10) * circumference;
  const color =
    score >= 7.5 ? "#4ade80" :
    score >= 5 ? "#facc15" :
    "#f87171";
  const glow =
    score >= 7.5 ? "rgba(74,222,128,0.35)" :
    score >= 5 ? "rgba(250,204,21,0.35)" :
    "rgba(248,113,113,0.35)";

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={9} />
      <circle
        cx={size / 2} cy={size / 2} r={radius}
        fill="none" stroke={color} strokeWidth={9}
        strokeDasharray={`${filled} ${circumference}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        filter="url(#glow)"
        style={{ opacity: 0.9 }}
      />
      <text x="50%" y="46%" textAnchor="middle" dominantBaseline="central"
        fill="white" fontSize={size * 0.24} fontWeight="800" letterSpacing="-1">
        {score.toFixed(1)}
      </text>
      <text x="50%" y="68%" textAnchor="middle" dominantBaseline="central"
        fill="rgba(255,255,255,0.3)" fontSize={size * 0.1} fontWeight="500">
        out of 10
      </text>
    </svg>
  );
}

function ScoreBar({ score }: { score: number }) {
  const color =
    score >= 7.5 ? "bg-green-400" :
    score >= 5 ? "bg-yellow-400" :
    "bg-red-400";
  return (
    <div className="w-full h-1 bg-white/[0.07] rounded-full overflow-hidden">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${(score / 10) * 100}%` }} />
    </div>
  );
}

function ScoreAccent({ score }: { score: number }) {
  if (score >= 7.5) return <div className="absolute left-0 inset-y-0 w-[3px] rounded-l-xl bg-green-400/60" />;
  if (score >= 5) return <div className="absolute left-0 inset-y-0 w-[3px] rounded-l-xl bg-yellow-400/60" />;
  return <div className="absolute left-0 inset-y-0 w-[3px] rounded-l-xl bg-red-400/60" />;
}

// ─── Materials components ────────────────────────────────────────────────────

const AVAILABILITY_CONFIG: Record<string, { label: string; class: string }> = {
  easy: { label: "Easy", class: "bg-green-500/15 text-green-400 border-green-500/25" },
  moderate: { label: "Moderate", class: "bg-yellow-500/15 text-yellow-400 border-yellow-500/25" },
  hard: { label: "Hard", class: "bg-red-500/15 text-red-400 border-red-500/25" },
  uncertain: { label: "Uncertain", class: "bg-white/[0.07] text-white/40 border-white/15" },
};

const COST_CONFIG: Record<string, { label: string; class: string }> = {
  low: { label: "$", class: "text-green-400" },
  medium: { label: "$$", class: "text-yellow-400" },
  high: { label: "$$$", class: "text-red-400" },
  unknown: { label: "?", class: "text-white/30" },
};

const RISK_CONFIG: Record<string, { label: string; class: string; bg: string }> = {
  low: { label: "Low Risk", class: "text-green-400", bg: "bg-green-500/[0.08] border-green-500/20" },
  medium: { label: "Medium Risk", class: "text-yellow-400", bg: "bg-yellow-500/[0.08] border-yellow-500/20" },
  high: { label: "High Risk", class: "text-red-400", bg: "bg-red-500/[0.08] border-red-500/20" },
};

function MaterialCard({ item }: { item: MaterialItem }) {
  const [expanded, setExpanded] = useState(false);
  const avail = AVAILABILITY_CONFIG[item.availability] ?? AVAILABILITY_CONFIG.uncertain;
  const cost = COST_CONFIG[item.cost_estimate] ?? COST_CONFIG.unknown;

  return (
    <div className="bg-white/[0.03] border border-white/[0.07] rounded-xl p-4 hover:bg-white/[0.05] transition-colors">
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-white text-[13px] truncate">{item.name}</div>
          <div className="text-[11px] text-white/40 mt-0.5 line-clamp-2 leading-relaxed">{item.purpose}</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className={`text-sm font-bold tabular-nums ${cost.class}`}>{cost.label}</span>
          <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold tracking-wide ${avail.class}`}>{avail.label}</span>
        </div>
      </div>
      <div className="text-[11px] text-white/30 mb-2">
        <span className="text-white/20">From: </span>{item.real_world_sources}
      </div>
      {item.substitutes.length > 0 && (
        <button
          onClick={() => setExpanded((e) => !e)}
          className="flex items-center gap-1 text-[11px] text-[hsl(210,100%,60%)]/70 hover:text-[hsl(210,100%,70%)] transition-colors"
        >
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          {item.substitutes.length} substitute{item.substitutes.length !== 1 ? "s" : ""}
        </button>
      )}
      {expanded && (
        <ul className="mt-2 space-y-1">
          {item.substitutes.map((sub, i) => (
            <li key={i} className="flex items-start gap-1.5 text-[11px] text-white/50">
              <ChevronRight className="w-3 h-3 text-[hsl(210,100%,60%)]/50 flex-shrink-0 mt-0.5" />{sub}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function MaterialsSection({ projectId }: { projectId: number }) {
  const queryClient = useQueryClient();
  const [analyzing, setAnalyzing] = useState(false);

  const { data: analysis, isFetching } = useGetMaterialsAnalysis(projectId, {
    query: {
      enabled: !!projectId,
      retry: false,
      throwOnError: false,
      queryKey: getGetMaterialsAnalysisQueryKey(projectId),
    },
  });

  const analyzeMutation = useAnalyzeMaterials();

  async function handleAnalyze() {
    setAnalyzing(true);
    try {
      await analyzeMutation.mutateAsync({ id: projectId });
      await queryClient.invalidateQueries({ queryKey: getGetMaterialsAnalysisQueryKey(projectId) });
    } finally {
      setAnalyzing(false);
    }
  }

  if (isFetching && !analyzing) {
    return (
      <div className="flex items-center justify-center py-12 gap-3 border border-white/[0.07] rounded-2xl">
        <Loader2 className="w-4 h-4 text-[hsl(210,100%,60%)] animate-spin" />
        <span className="text-white/40 text-sm">Loading…</span>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="border border-dashed border-white/[0.08] rounded-2xl p-12 flex flex-col items-center gap-5 text-center">
        <div className="w-11 h-11 rounded-xl bg-[hsl(210,100%,60%)]/[0.08] flex items-center justify-center ring-1 ring-[hsl(210,100%,60%)]/15">
          <Package className="w-5 h-5 text-[hsl(210,100%,60%)]/70" />
        </div>
        <div>
          <div className="font-semibold text-white/80 text-sm mb-1">No materials analysis yet</div>
          <div className="text-xs text-white/30 max-w-xs leading-relaxed">
            Identify every material, check real-world availability, estimated costs, and get substitute suggestions.
          </div>
        </div>
        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="flex items-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold px-6 py-2.5 rounded-xl hover:bg-[hsl(210,100%,68%)] transition-colors text-sm disabled:opacity-60 shadow-lg shadow-[hsl(210,100%,60%)]/20"
        >
          {analyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Package className="w-3.5 h-3.5" />}
          {analyzing ? "Analyzing…" : "Analyze Materials"}
        </button>
        {analyzing && <p className="text-xs text-white/25">Usually takes 10–15 seconds</p>}
      </div>
    );
  }

  const { feasibilitySummary: fs, materialsImpactScore: mis, recommendations: rec, materials } = analysis as MaterialsAnalysis & {
    feasibilitySummary: MaterialsAnalysis["feasibilitySummary"];
    materialsImpactScore: MaterialsAnalysis["materialsImpactScore"];
    recommendations: MaterialsAnalysis["recommendations"];
  };

  const risk = RISK_CONFIG[fs.execution_risk_level] ?? RISK_CONFIG.medium;
  const impactColor = mis.score >= 3 ? "text-green-400" : mis.score >= 0 ? "text-yellow-400" : "text-red-400";
  const impactSign = mis.score > 0 ? "+" : "";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white/[0.03] border border-white/[0.07] rounded-xl p-5 flex flex-col items-center gap-1.5">
          <div className="text-[10px] text-white/30 uppercase tracking-widest font-semibold">Feasibility</div>
          <div className="text-3xl font-black text-white tabular-nums">{fs.overall_feasibility_score}<span className="text-base text-white/20 font-medium">/10</span></div>
        </div>
        <div className={`border rounded-xl p-5 flex flex-col items-center gap-1.5 ${risk.bg}`}>
          <div className="text-[10px] text-white/30 uppercase tracking-widest font-semibold">Exec Risk</div>
          <div className={`text-lg font-bold ${risk.class}`}>{risk.label}</div>
        </div>
        <div className="bg-white/[0.03] border border-white/[0.07] rounded-xl p-5 flex flex-col items-center gap-1.5">
          <div className="text-[10px] text-white/30 uppercase tracking-widest font-semibold">Impact</div>
          <div className={`text-3xl font-black tabular-nums ${impactColor}`}>{impactSign}{mis.score}</div>
        </div>
      </div>

      <div className="bg-white/[0.03] border border-white/[0.07] rounded-xl p-5">
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-3.5 h-3.5 text-[hsl(210,100%,60%)]/70" />
          <span className="text-[10px] font-bold text-[hsl(210,100%,60%)]/70 uppercase tracking-widest">Impact Reasoning</span>
        </div>
        <p className="text-sm text-white/60 leading-relaxed">{mis.reasoning}</p>
      </div>

      <div>
        <div className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-3 flex items-center gap-2">
          <Package className="w-3.5 h-3.5" /> Required Materials ({materials.length})
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {materials.map((item, i) => <MaterialCard key={i} item={item as MaterialItem} />)}
        </div>
      </div>

      {(fs.material_bottlenecks.length > 0 || fs.key_constraints.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {fs.material_bottlenecks.length > 0 && (
            <div className="bg-red-500/[0.05] border border-red-500/15 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <ShieldAlert className="w-3.5 h-3.5 text-red-400/80" />
                <span className="text-[10px] font-bold text-red-400/80 uppercase tracking-widest">Bottlenecks</span>
              </div>
              <ul className="space-y-2">
                {fs.material_bottlenecks.map((b, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                    <ChevronRight className="w-3 h-3 text-red-400/50 flex-shrink-0 mt-0.5" />{b}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {fs.key_constraints.length > 0 && (
            <div className="bg-yellow-500/[0.05] border border-yellow-500/15 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-3.5 h-3.5 text-yellow-400/80" />
                <span className="text-[10px] font-bold text-yellow-400/80 uppercase tracking-widest">Constraints</span>
              </div>
              <ul className="space-y-2">
                {fs.key_constraints.map((c, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                    <ChevronRight className="w-3 h-3 text-yellow-400/50 flex-shrink-0 mt-0.5" />{c}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      <div className="bg-white/[0.03] border border-white/[0.07] rounded-2xl p-6 space-y-5">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5 text-[hsl(210,100%,60%)]/70" />
          <span className="text-xs font-bold text-white/70 tracking-tight">Expert Recommendations</span>
        </div>
        {rec.simplifications.length > 0 && (
          <div>
            <div className="text-[10px] font-bold text-green-400/70 uppercase tracking-widest mb-2">Simplifications</div>
            <ul className="space-y-1.5">
              {rec.simplifications.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-xs text-white/55">
                  <CheckCircle2 className="w-3 h-3 text-green-400/50 flex-shrink-0 mt-0.5" />{s}
                </li>
              ))}
            </ul>
          </div>
        )}
        {rec.substitutions_strategy.length > 0 && (
          <div>
            <div className="text-[10px] font-bold text-[hsl(210,100%,60%)]/60 uppercase tracking-widest mb-2">Substitutions</div>
            <ul className="space-y-1.5">
              {rec.substitutions_strategy.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-xs text-white/55">
                  <ChevronRight className="w-3 h-3 text-[hsl(210,100%,60%)]/40 flex-shrink-0 mt-0.5" />{s}
                </li>
              ))}
            </ul>
          </div>
        )}
        {rec.warnings.length > 0 && (
          <div>
            <div className="text-[10px] font-bold text-yellow-400/70 uppercase tracking-widest mb-2">Warnings</div>
            <ul className="space-y-1.5">
              {rec.warnings.map((w, i) => (
                <li key={i} className="flex items-start gap-2 text-xs text-white/55">
                  <AlertTriangle className="w-3 h-3 text-yellow-400/50 flex-shrink-0 mt-0.5" />{w}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="flex items-center gap-1.5 border border-white/10 text-white/40 hover:text-white/70 hover:border-white/20 transition-colors text-xs px-3 py-1.5 rounded-lg"
        >
          {analyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RotateCcw className="w-3 h-3" />}
          Re-analyze
        </button>
      </div>
    </div>
  );
}

// ─── Main Results page ───────────────────────────────────────────────────────

export default function Results() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0", 10);
  const queryClient = useQueryClient();
  const [retrying, setRetrying] = useState(false);
  const [activeTab, setActiveTab] = useState<"evaluation" | "materials">("evaluation");

  const { data, isLoading } = useGetProject(id, {
    query: { enabled: !!id, queryKey: getGetProjectQueryKey(id) },
  });

  const retryEvaluation = useRetryEvaluation();

  async function handleRetry() {
    if (!data?.evaluation) return;
    setRetrying(true);
    try {
      await retryEvaluation.mutateAsync({ id: data.evaluation.id });
      await queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(id) });
    } finally {
      setRetrying(false);
    }
  }

  const evaluation = data?.evaluation;
  const project = data?.project;

  const categories = evaluation
    ? ([
        ["scientificValidity", evaluation.scientificValidity],
        ["feasibility", evaluation.feasibility],
        ["originality", evaluation.originality],
        ["engineeringComplexity", evaluation.engineeringComplexity],
        ["judgeAppeal", evaluation.judgeAppeal],
        ["scalability", evaluation.scalability],
        ["dataQuality", evaluation.dataQuality],
        ["failureRisk", evaluation.failureRisk],
      ] as [string, EvalCategory][])
    : [];

  return (
    <div className="min-h-screen bg-[hsl(222,47%,7%)] text-white">
      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b border-white/[0.06] bg-[hsl(222,47%,7%)]/80 backdrop-blur-md px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 text-white/60 hover:text-white transition-colors">
            <div className="w-6 h-6 rounded-md bg-[hsl(210,100%,60%)]/15 flex items-center justify-center ring-1 ring-[hsl(210,100%,60%)]/25">
              <FlaskConical className="w-3.5 h-3.5 text-[hsl(210,100%,60%)]" />
            </div>
            <span className="font-semibold text-sm text-white/80">ScienceFair Copilot</span>
          </Link>
          <Link href="/projects" className="text-xs text-white/35 hover:text-white/70 transition-colors flex items-center gap-1.5">
            <ArrowLeft className="w-3.5 h-3.5" /> My Projects
          </Link>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-10">
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-32 gap-3">
            <Loader2 className="w-8 h-8 text-[hsl(210,100%,60%)]/60 animate-spin" />
            <p className="text-white/30 text-sm">Loading…</p>
          </div>
        )}

        {!isLoading && project && (
          <>
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-start justify-between flex-wrap gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <span className="text-[10px] font-bold text-white/25 uppercase tracking-widest border border-white/[0.08] rounded px-2 py-0.5">
                      Grade {project.gradeLevel}
                    </span>
                    <span className="text-[10px] font-bold text-white/25 uppercase tracking-widest border border-white/[0.08] rounded px-2 py-0.5">
                      {project.budget}
                    </span>
                    <span className="text-[10px] font-bold text-white/25 uppercase tracking-widest border border-white/[0.08] rounded px-2 py-0.5">
                      {project.timeline}
                    </span>
                  </div>
                  <h1 className="text-3xl font-bold tracking-tight leading-tight" data-testid="project-title">
                    {project.title}
                  </h1>
                  <p className="text-white/40 mt-2 max-w-2xl text-sm leading-relaxed">{project.description}</p>
                </div>
                {evaluation && activeTab === "evaluation" && (
                  <button
                    onClick={handleRetry}
                    disabled={retrying}
                    className="flex items-center gap-1.5 border border-white/10 text-white/40 hover:text-white/70 hover:border-white/20 transition-all text-xs px-3.5 py-2 rounded-lg"
                    data-testid="button-retry"
                  >
                    {retrying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                    Re-evaluate
                  </button>
                )}
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-0.5 mb-8 border-b border-white/[0.07]">
              {(["evaluation", "materials"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2.5 text-xs font-bold tracking-wide uppercase transition-colors border-b-2 -mb-px flex items-center gap-1.5 ${
                    activeTab === tab
                      ? "border-[hsl(210,100%,60%)] text-white"
                      : "border-transparent text-white/30 hover:text-white/60"
                  }`}
                >
                  {tab === "materials" && <Package className="w-3 h-3" />}
                  {tab === "evaluation" ? "Rubric Evaluation" : "Materials"}
                </button>
              ))}
            </div>

            {/* No evaluation yet */}
            {!evaluation && activeTab === "evaluation" && (
              <div className="flex flex-col items-center justify-center py-24 gap-4 border border-white/[0.07] rounded-2xl">
                <Loader2 className="w-8 h-8 text-[hsl(210,100%,60%)]/60 animate-spin" />
                <p className="text-white/40 text-sm">AI judges are evaluating your project…</p>
                <p className="text-white/20 text-xs">Usually 10–20 seconds</p>
              </div>
            )}

            {/* Evaluation tab */}
            {activeTab === "evaluation" && evaluation && (
              <>
                {/* Score + highlights */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
                  <div className="bg-white/[0.03] border border-white/[0.07] rounded-2xl p-8 flex flex-col items-center gap-2">
                    <ScoreRing score={evaluation.overallScore} size={148} />
                    <div className="text-[10px] font-bold text-white/25 uppercase tracking-widest mt-1">Overall Score</div>
                  </div>

                  <div className="md:col-span-2 flex flex-col gap-4">
                    <div className="flex-1 bg-green-500/[0.06] border border-green-500/15 rounded-xl p-5">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-green-400/80" />
                        <span className="text-[10px] font-bold text-green-400/80 uppercase tracking-widest">Strongest Aspect</span>
                      </div>
                      <div className="font-bold text-white/90 text-sm" data-testid="strongest-aspect">
                        {formatAspectName(evaluation.strongestAspect)}
                      </div>
                    </div>
                    <div className="flex-1 bg-yellow-500/[0.06] border border-yellow-500/15 rounded-xl p-5">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="w-3.5 h-3.5 text-yellow-400/80" />
                        <span className="text-[10px] font-bold text-yellow-400/80 uppercase tracking-widest">Needs Most Work</span>
                      </div>
                      <div className="font-bold text-white/90 text-sm" data-testid="weakest-aspect">
                        {formatAspectName(evaluation.weakestAspect)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Judge summary */}
                <div className="bg-white/[0.03] border border-white/[0.07] rounded-2xl p-6 mb-8">
                  <div className="text-[10px] font-bold text-[hsl(210,100%,60%)]/60 uppercase tracking-widest mb-3">Judge Summary</div>
                  <p className="text-white/65 leading-relaxed text-sm" data-testid="judge-summary">{evaluation.judgeSummary}</p>
                </div>

                {/* Category breakdown */}
                <div className="mb-5">
                  <h2 className="text-sm font-bold text-white/70 uppercase tracking-widest mb-0.5">Detailed Breakdown</h2>
                  <p className="text-white/30 text-xs">Each dimension scored 0–10 with expert reasoning and actionable feedback.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {categories.map(([key, cat]) => (
                    <div
                      key={key}
                      className="relative bg-white/[0.03] border border-white/[0.07] rounded-xl p-5 hover:bg-white/[0.05] transition-colors overflow-hidden"
                      data-testid={`card-category-${key}`}
                    >
                      <ScoreAccent score={cat.score} />
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-xs font-semibold text-white/70">{CATEGORY_LABELS[key]}</div>
                        <div className="text-base font-black tabular-nums text-white">{cat.score.toFixed(1)}</div>
                      </div>
                      <ScoreBar score={cat.score} />
                      <p className="text-[11px] text-white/40 mt-3 leading-relaxed">{cat.reasoning}</p>
                      <div className="mt-3 flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 text-[hsl(210,100%,60%)]/50 flex-shrink-0 mt-0.5" />
                        <p className="text-[11px] text-[hsl(210,100%,65%)]/70 leading-relaxed">{cat.suggestion}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-10 flex items-center justify-between">
                  <Link
                    href="/submit"
                    className="inline-flex items-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold px-6 py-2.5 rounded-xl hover:bg-[hsl(210,100%,68%)] transition-colors text-sm shadow-lg shadow-[hsl(210,100%,60%)]/20"
                    data-testid="link-evaluate-another"
                  >
                    Evaluate Another Project
                  </Link>
                  <Link href="/projects" className="text-xs text-white/30 hover:text-white/60 transition-colors">
                    My Projects →
                  </Link>
                </div>
              </>
            )}

            {/* Materials tab */}
            {activeTab === "materials" && <MaterialsSection projectId={id} />}
          </>
        )}
      </div>
    </div>
  );
}
