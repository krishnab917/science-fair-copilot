import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, Link } from "wouter";
import { useState } from "react";
import { useCreateProject, useEvaluateProject, getGetProjectQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { addMyProjectId } from "@/hooks/use-my-projects";
import { FlaskConical, ArrowLeft, Loader2, Sparkles } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const schema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(30, "Please provide a more detailed description (at least 30 characters)"),
  gradeLevel: z.string().min(1, "Please select a grade level"),
  budget: z.string().min(1, "Please enter a budget"),
  timeline: z.string().min(1, "Please enter a timeline"),
});

type FormValues = z.infer<typeof schema>;

const GRADE_LEVELS = ["K-5", "6-8", "9-12", "College"];

const inputClass = "bg-white/[0.04] border-white/10 text-white placeholder:text-white/20 focus:border-[hsl(210,100%,55%)]/60 focus:ring-2 focus:ring-[hsl(210,100%,55%)]/15 rounded-lg transition-all";

export default function Submit() {
  const [, setLocation] = useLocation();
  const [phase, setPhase] = useState<"idle" | "creating" | "evaluating">("idle");
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const createProject = useCreateProject();
  const evaluateProject = useEvaluateProject();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", description: "", gradeLevel: "", budget: "", timeline: "" },
  });

  const isLoading = phase !== "idle";

  async function onSubmit(values: FormValues) {
    setError(null);
    setPhase("creating");

    let project;
    try {
      project = await createProject.mutateAsync({ data: values });
    } catch {
      setPhase("idle");
      setError("Failed to create project. Please try again.");
      return;
    }

    addMyProjectId(project.id);
    setPhase("evaluating");

    try {
      await evaluateProject.mutateAsync({ id: project.id });
      await queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(project.id) });
      setLocation(`/results/${project.id}`);
    } catch {
      setPhase("idle");
      setError("Project created but AI evaluation failed. You can try again from the project page.");
      setLocation(`/results/${project.id}`);
    }
  }

  return (
    <div className="min-h-screen bg-[hsl(222,47%,7%)] text-white">
      {/* Nav */}
      <nav className="border-b border-white/[0.06] bg-[hsl(222,47%,7%)]/80 backdrop-blur-md px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 text-white/70 hover:text-white transition-colors">
            <div className="w-6 h-6 rounded-md bg-[hsl(210,100%,60%)]/15 flex items-center justify-center ring-1 ring-[hsl(210,100%,60%)]/25">
              <FlaskConical className="w-3.5 h-3.5 text-[hsl(210,100%,60%)]" />
            </div>
            <span className="font-semibold text-sm">ScienceFair Copilot</span>
          </Link>
          <Link href="/projects" className="text-sm text-white/40 hover:text-white/70 transition-colors flex items-center gap-1.5">
            <ArrowLeft className="w-3.5 h-3.5" />
            My Projects
          </Link>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-6 py-14">

        {/* Header */}
        <div className="mb-10">
          <div className="text-[11px] font-bold text-[hsl(210,100%,60%)]/70 uppercase tracking-[0.1em] mb-3">New Submission</div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Submit Your Project</h1>
          <p className="text-white/40 text-sm leading-relaxed">
            Describe your project and our AI judge will evaluate it across 8 expert dimensions.
          </p>
        </div>

        {/* Loading state */}
        {isLoading && (
          <div className="mb-8 bg-[hsl(210,100%,60%)]/[0.07] border border-[hsl(210,100%,60%)]/15 rounded-xl p-5 flex items-center gap-4">
            <div className="w-8 h-8 rounded-lg bg-[hsl(210,100%,60%)]/10 flex items-center justify-center flex-shrink-0">
              <Loader2 className="w-4 h-4 text-[hsl(210,100%,60%)] animate-spin" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white/90">
                {phase === "creating" ? "Creating your project…" : "AI judges are reviewing your project…"}
              </div>
              <div className="text-xs text-white/40 mt-0.5">
                {phase === "evaluating" && "This may take 10–20 seconds. Please don't close the page."}
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-8 bg-red-500/[0.07] border border-red-500/20 rounded-xl p-4 text-red-300/90 text-sm">
            {error}
          </div>
        )}

        {/* Form card */}
        <div className="bg-white/[0.02] border border-white/[0.07] rounded-2xl p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">

              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs font-semibold text-white/50 uppercase tracking-widest">Project Title</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="e.g. Effect of Microplastics on Plant Growth"
                        className={inputClass}
                        disabled={isLoading}
                        data-testid="input-title"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs font-semibold text-white/50 uppercase tracking-widest">Project Description</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Describe your hypothesis, methodology, expected outcomes, and what makes it unique…"
                        rows={6}
                        className={`${inputClass} resize-none`}
                        disabled={isLoading}
                        data-testid="input-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <FormField
                  control={form.control}
                  name="gradeLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-semibold text-white/50 uppercase tracking-widest">Grade Level</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value} disabled={isLoading}>
                        <FormControl>
                          <SelectTrigger className={`${inputClass} w-full`} data-testid="select-grade-level">
                            <SelectValue placeholder="Select grade" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-[hsl(222,47%,11%)] border-white/10 text-white">
                          {GRADE_LEVELS.map((g) => (
                            <SelectItem key={g} value={g} className="focus:bg-white/10 text-white/80">
                              {g}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-semibold text-white/50 uppercase tracking-widest">Budget</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g. $50"
                          className={inputClass}
                          disabled={isLoading}
                          data-testid="input-budget"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="timeline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-semibold text-white/50 uppercase tracking-widest">Timeline</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g. 4 weeks"
                          className={inputClass}
                          disabled={isLoading}
                          data-testid="input-timeline"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 bg-[hsl(210,100%,60%)] text-[hsl(222,47%,8%)] font-bold px-8 py-3.5 rounded-xl text-[15px] hover:bg-[hsl(210,100%,68%)] transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-[hsl(210,100%,60%)]/20"
                  data-testid="button-submit"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      {phase === "creating" ? "Creating…" : "Evaluating…"}
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Evaluate My Project
                    </>
                  )}
                </button>
              </div>

            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
