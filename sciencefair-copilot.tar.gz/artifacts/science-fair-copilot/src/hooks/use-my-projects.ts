const STORAGE_KEY = "sfcopilot_my_project_ids";

function readIds(): number[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((v): v is number => typeof v === "number");
  } catch {
    return [];
  }
}

function writeIds(ids: number[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  } catch {
    // storage unavailable — silently ignore
  }
}

export function getMyProjectIds(): number[] {
  return readIds();
}

export function addMyProjectId(id: number): void {
  const current = readIds();
  if (!current.includes(id)) {
    writeIds([...current, id]);
  }
}
