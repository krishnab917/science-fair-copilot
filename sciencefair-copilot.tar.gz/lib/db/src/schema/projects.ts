import { pgTable, serial, text, real, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const projectsTable = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  gradeLevel: text("grade_level").notNull(),
  budget: text("budget").notNull(),
  timeline: text("timeline").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({ id: true, createdAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;

export const evaluationCategorySchema = z.object({
  score: z.number(),
  reasoning: z.string(),
  suggestion: z.string(),
});

export const evaluationsTable = pgTable("evaluations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projectsTable.id),
  overallScore: real("overall_score").notNull(),
  strongestAspect: text("strongest_aspect").notNull(),
  weakestAspect: text("weakest_aspect").notNull(),
  judgeSummary: text("judge_summary").notNull(),
  scientificValidity: jsonb("scientific_validity").notNull(),
  feasibility: jsonb("feasibility").notNull(),
  originality: jsonb("originality").notNull(),
  engineeringComplexity: jsonb("engineering_complexity").notNull(),
  judgeAppeal: jsonb("judge_appeal").notNull(),
  scalability: jsonb("scalability").notNull(),
  dataQuality: jsonb("data_quality").notNull(),
  failureRisk: jsonb("failure_risk").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEvaluationSchema = createInsertSchema(evaluationsTable).omit({ id: true, createdAt: true });
export type InsertEvaluation = z.infer<typeof insertEvaluationSchema>;
export type Evaluation = typeof evaluationsTable.$inferSelect;

export const materialsAnalysisTable = pgTable("materials_analysis", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projectsTable.id),
  materials: jsonb("materials").notNull(),
  feasibilitySummary: jsonb("feasibility_summary").notNull(),
  materialsImpactScore: jsonb("materials_impact_score").notNull(),
  recommendations: jsonb("recommendations").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMaterialsAnalysisSchema = createInsertSchema(materialsAnalysisTable).omit({ id: true, createdAt: true });
export type InsertMaterialsAnalysis = z.infer<typeof insertMaterialsAnalysisSchema>;
export type MaterialsAnalysis = typeof materialsAnalysisTable.$inferSelect;
