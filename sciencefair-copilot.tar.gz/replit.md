# ScienceFair Copilot

An AI-powered science fair evaluator that scores student project ideas across 8 expert rubric dimensions using OpenAI.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/science-fair-copilot run dev` — run the frontend (port 21783)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `AI_INTEGRATIONS_OPENAI_BASE_URL`, `AI_INTEGRATIONS_OPENAI_API_KEY` — auto-provisioned via Replit AI Integrations

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS (wouter routing, shadcn/ui, TanStack Query)
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- AI: OpenAI gpt-5.4 via Replit AI Integrations (no user API key needed)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/projects.ts` — DB schema (projects + evaluations tables)
- `artifacts/api-server/src/routes/projects.ts` — project CRUD + AI evaluation routes
- `artifacts/api-server/src/routes/evaluations.ts` — retry evaluation route
- `artifacts/api-server/src/lib/openai-evaluator.ts` — OpenAI rubric scoring engine
- `artifacts/science-fair-copilot/src/pages/` — frontend pages (home, submit, results, projects)

## Architecture decisions

- Contract-first API: OpenAPI spec → Orval codegen → typed React Query hooks + Zod validators
- AI evaluation is synchronous (request waits for OpenAI response) — keeps the flow simple for MVP
- Evaluations stored as JSONB columns per category for flexibility in the scoring schema
- OpenAI uses `response_format: { type: "json_object" }` for reliable structured output
- No authentication — public MVP scoped to core evaluation flow only

## Product

- Landing page with stats and rubric category overview
- Project submission form (title, description, grade level, budget, timeline)
- AI rubric evaluation across 8 dimensions: Scientific Validity, Feasibility, Originality, Engineering Complexity, Judge Appeal, Scalability, Data Quality Potential, Failure Risk
- Results dashboard with circular score indicator, per-category score bars, reasoning, and improvement suggestions
- Re-evaluate button to regenerate scores
- Projects list page showing all submissions

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After any OpenAPI spec change, always run `pnpm --filter @workspace/api-spec run codegen` before writing routes
- The `evaluationsTable` stores per-category data as JSONB — cast properly when reading back
- AI evaluation can take 10-20 seconds — frontend shows a loading state during this time
- `pnpm run dev` at workspace root does not exist by design; run workflows individually

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
